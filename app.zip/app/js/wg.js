var wg = angular.module('wg', ['ngAnimate', 'ui.router', 'ui.bootstrap', 'ngResource', 'ngSanitize', ])

	.config(function($stateProvider, $urlRouterProvider, $compileProvider) {
		//FOR UNMATCHED URL, REDIRECT TO HOME
		// $urlRouterProvider.otherwise('/root')

		// Set up routes
		$stateProvider
			.state('root', {
				url: '/:id',
				controller: "mainController"
			})
			.state('root.about', {
				url: '/about',
				templateUrl: './partials/about.html',
				controller: 'aboutController'
			})
			.state('root.files', {
				url: '/files',
				templateUrl: './partials/files.html',
				controller: 'filesController'
			})
			.state('root.demos', {
				url: '/demos',
				templateUrl: './partials/demos.html',
				controller: 'demosController'
			})

	   $compileProvider.debugInfoEnabled(false);
	})