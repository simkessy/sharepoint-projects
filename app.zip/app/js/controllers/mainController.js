wg.controller('mainController', function($scope, $timeout, $location, $stateParams, DataService){

	console.log('Entered main controller');
	$scope.wtf = "WERWEWER";
	var wg = $scope.wg = {
		id: $stateParams.id,
		get: function() {
			DataService.getWorkingGroup(wg.id).then(function(data) {
				wg.data = data[0];
				console.log(wg);
			});
		}
	};
	wg.get(wg.id);
});