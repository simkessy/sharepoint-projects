wg.controller('demosController', function($scope, $timeout, $stateParams){
	console.log('Entered demoes controller ')
	console.log($stateParams)
})