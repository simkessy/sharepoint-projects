wg.controller('aboutController', function($scope, $timeout, $stateParams){
	console.log('Entered about controller ')
	console.log($stateParams)
})