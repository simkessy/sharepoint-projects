wg.controller('filesController', function($scope, $timeout, $stateParams){
	console.log('Entered files controller ')
	console.log($stateParams)
})