wg.factory('DataService', ['$q', '$resource', '$http', function($q,$resource,$http){

	getWorkingGroup = function(id) {
		var d = $.Deferred();

		var promise = $().SPServices.SPGetListItemsJson({
			listName: "Attended Meetings",
			CAMLQuery: "<Query><Where><Eq><FieldRef Name='ID'/><Value Type='Number'>" + id + "</Value></Eq></Where></Query>"
		});

		promise.then(function() {
			d.resolve(this.data)
		});

		return d.promise();
	}


	return {
		getWorkingGroup:getWorkingGroup
	}
}])