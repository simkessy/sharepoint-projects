var wg = angular.module('wg', ['ngAnimate', 'ui.router', 'ui.bootstrap', 'ngResource', 'ngSanitize', ])

.config(function($stateProvider, $urlRouterProvider, $compileProvider) {
		//FOR UNMATCHED URL, REDIRECT TO HOME
		$urlRouterProvider.otherwise('/wg')

		// Set up routes
		$stateProvider
		.state('home',{
			url: '/',
			templateUrl: "./partials/home/home.html",
			controller: "mainController"
		})
		.state('home.wg', {
			url: "wg",
			templateUrl: "./partials/home/allWG.html",
		})
		.state('home.demos', {
			url: "demos",
			templateUrl: "./partials/home/allDemos.html",
		})
		.state('wg', {
			url: '/wg/:id',
			templateUrl: './partials/wg/wg.html',
			controller: "mainController"
		})
		.state('wg.about', {
			url: '/about',
			templateUrl: './partials/wg/about.html',
			controller: 'aboutController'
		})
		.state('wg.files', {
			url: '/files',
			templateUrl: './partials/wg/files.html',
			controller: 'filesController'
		})
		.state('wg.demos', {
			url: '/demos',
			templateUrl: './partials/wg/demos.html',
			controller: 'demosController'
		})

		$compileProvider.debugInfoEnabled(false);
	})

// Title case filter
.filter('titleCase', function() {
	return function(input) {
		input = input || '';
		return input.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
	};
})