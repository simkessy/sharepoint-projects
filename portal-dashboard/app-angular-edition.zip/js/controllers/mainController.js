wg.controller('mainController', function($scope, $timeout, $location, $stateParams, DataService) {
	console.log('main controller')
	var wg = $scope.wg = {
		id: $stateParams.id,
		dateFormat: "MMM Do, h:mm:ss a",
		init: function() {
			console.log($stateParams)
			wg.get()
				.then(wg.files)
				.then(wg.demos)
				.then(wg.blog)
				.then(function() {
					// Update the view once data retrieved
					$scope.$apply();
				})
		},
		processGroups: function(data) {
			var grouped = _.groupBy(data, 'WG_Type');
			return Object.keys(grouped).sort().reduce(function (result, key) {
		        result[key] = _.sortBy(grouped[key], "Title");
		        return result;
			}, {});
		},
		processAttendees: function(data) {
			var attendance = wg.data.Attendee_x0028_s_x0029_;
			if(_.isNull(attendance)) {
				wg.data.attendees = "";
			}else {
				wg.data.attendees = wg.data.Attendee_x0028_s_x0029_.map(function(x) {
					return x.userName;
				}).toString().replace(",", ", ");
			}
		},
		get: function() {
			console.log('getting wg data')
			return DataService.getWorkingGroup(wg.id).then(function(data) {
				var isAllWG = (data.length > 1) ? true : false;
				wg.data = isAllWG ? wg.processGroups(data) : data[0];

				if(!isAllWG) {
					wg.processAttendees(wg.data)
				}
				console.log(wg.data)
			});
		},
		files: function() {
			console.log('getting files')
			return DataService.files(wg.id).then(function(files){
				wg.files = files
				wg.files.map(function(file,index){
					wg.files[index].filename = file.FileRef.lookupValue.split("/").slice(-1)[0].split(".")[0];
					wg.files[index].modified = moment(file.Modified).format(wg.dateFormat);
				})
				console.log(wg.files)
			})
		},
		demos: function() {
			console.log('getting demos');
			return DataService.demos(wg.id).then(function(demos) {
				wg.demos = demos;
				console.log(wg.demos);
				wg.demos.map(function(demo,index){
					wg.demos[index].start = moment(demo.EventDate).format(wg.dateFormat);
					wg.demos[index].end = moment(demo.EndDate).format(wg.dateFormat);
				})
			})
		},
		blog: function() {
			console.log('getting blog');
			return DataService.blog().then(function(posts) {
				wg.posts = posts;
				console.log(wg.posts)
			})
		}
	};
	wg.init();
});