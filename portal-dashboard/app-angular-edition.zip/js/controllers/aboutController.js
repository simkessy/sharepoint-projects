wg.controller('aboutController', function($scope, $timeout, $stateParams){
	console.log('about controller')
})