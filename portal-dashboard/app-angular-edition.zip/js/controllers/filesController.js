wg.controller('filesController', function($scope, $timeout, $stateParams, DataService){
	console.log('files controller')

})