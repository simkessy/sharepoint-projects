wg.factory('DataService', ['$q', '$resource', '$http', function($q,$resource,$http){

	getWorkingGroups = function(id) {
		var d = $.Deferred();

		var operation = {
			listName: "Attended Meetings"
		}

		if (!_.isUndefined(id)) {
			operation.CAMLQuery = "<Query><Where><Eq><FieldRef Name='ID'/><Value Type='Number'>" + id + "</Value></Eq></Where></Query>"
		}

		var promise = $().SPServices.SPGetListItemsJson(operation);

		promise.then(function() {
			d.resolve(this.data)
		});

		return d.promise();
	};

	getBlogPosts = function() {
		var d = $.Deferred();

		var getPosts = $().SPServices.SPGetListItemsJson({
			listName: "Posts",
			webURL: "/sites/hrcivpm/CHRCT-TCRHC/WN"
		})

		getPosts.then(function() {
			var results = this.data;
			results.map(function(post) {
				post.PublishedDate = post.PublishedDate.getTime();
				post.link = "/sites/hrcivpm/CHRCT-TCRHC/WN/Lists/Posts/Post.aspx?ID=" + post.ID;
			})
			
			results  = _.sortBy(results, "PublishedDate");
			results.map(function(post) {
				post.PublishedDate = moment(post.PublishedDate).format("MMM Do YYYY, h:mm a")
			})

			results.reverse();

			d.resolve(results);
		})
		return d.promise();
	};

	getFiles = function(id) {
		var d = $.Deferred();

		var promise = $().SPServices.SPGetListItemsJson({
			listName: "Working Groups",
			CAMLQuery: "<Query><Where><And><Eq><FieldRef Name='FSObjType' /><Value Type='Integer'>0</Value></Eq><Eq><FieldRef Name='wgID'/><Value Type='Text'>" + id + "</Value></Eq></And></Where></Query>",
			CAMLQueryOptions: "<QueryOptions><ViewAttributes Scope='RecursiveAll' /></QueryOptions>",
		});

		promise.then(function() {
			var files = this.data
			files.map(function(date,index) {
				files[index].modified = moment(date).format('MMMM Do @ HH:MMa')
			})			
			d.resolve(this.data);
		});

		return d.promise();	
	};

	getDemos = function(id) {
		var d = $.Deferred();

		var operation = {
			listName: "Demos",
		}

		if(!_.isUndefined(id)) {
			operation.CAMLQuery = "<Query><Where><Eq><FieldRef Name='wgID_x003a_ID'/><Value Type='Text'>" + id + "</Value></Eq></Where></Query>";
			operation.CAMLQueryOptions = "<QueryOptions><ViewAttributes Scope='RecursiveAll' /></QueryOptions>";
		}

		var promise = $().SPServices.SPGetListItemsJson(operation);

		promise.then(function() {
			d.resolve(this.data)
		});

		return d.promise();	
	};


	return {
		getWorkingGroup:getWorkingGroups,
		files: getFiles,
		demos: getDemos,
		blog: getBlogPosts
	};
}])

